ember install ember-service-worker
ember install ember-service-worker-index
ember install ember-service-worker-asset-cache
ember install ember-service-worker-cache-fallback
