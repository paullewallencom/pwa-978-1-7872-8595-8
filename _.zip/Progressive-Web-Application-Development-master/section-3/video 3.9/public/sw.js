self.addEventListener('install', function (event) {});

self.addEventListener('activate', function (event) {});

self.addEventListener('fetch', function (event) {});
